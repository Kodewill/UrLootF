<?php $__env->startSection('content'); ?>

<div class='container'>
    <div class = "col-md-8 col-md-offset-2">
        <h1>Examenes</h1>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\UrLootF\UrLoot\resources\views/web/post.blade.php ENDPATH**/ ?>